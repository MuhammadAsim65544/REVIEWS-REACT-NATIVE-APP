import React, { useState } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity } from 'react-native';
import { golbalStyles } from '../Styles/Global';

export default function Home({ navigation }) {
  const [rewies, setReviews] = useState([
    { title: 'Zelda, Breath Of Fresh Air', rating: 5, key: 1 },
    { title: 'Gotta Catch All of them', rating: 5, key: 2 },
    { title: 'Product is quite good', rating: 4, key: 3 },
    { title: 'Poor quality of the shirt', rating: 2, key: 4 },
    {
      title: 'Average quality, best due to this price range',
      rating: 3,
      key: 5,
    },
    { title: 'Poor Quality. ', rating: 2, key: 6 },
    { title: 'Very good Quality. 100% satisfied', rating: 5, key: 7 },
    { title: 'Very poor quality, Do not waste your money', rating: 1, key: 8 },
  ]);
  return (
    <View style={golbalStyles.container}>
      <FlatList
        data={rewies}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('ReviewDetails', {
                title: item.title,
                rating: item.rating,
                key: item.key,
              })
            }>
            <Text style={golbalStyles.titleText}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
