import React from 'react';
import {View,Text} from 'react-native';
import {golbalStyles} from '../Styles/Global';
export default function About({navigation}){
  return(
    <View style={golbalStyles.container}>
      <Text style={golbalStyles.titleText}>Product reviews allows you to            add a customer review feature to your products. This provides a            way for your customers to engage with you, as well as each other           to encourage sales.
      </Text>
    </View>
  )
}