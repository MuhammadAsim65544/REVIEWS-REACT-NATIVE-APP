import React from 'react';
import {View,Text} from 'react-native';
import {golbalStyles} from '../Styles/Global';
export default function ReviewDetails({route,navigation}){
  
   const {title,rating,key}=route.params;
  return(
    <View style={golbalStyles.container}>
      <Text style={golbalStyles.reviewdetail}>{JSON.stringify(title)}</Text>
      <Text style={golbalStyles.reviewdetail}>{JSON.stringify(rating)}</Text>
      <Text style={golbalStyles.reviewdetail}>{JSON.stringify(key)}</Text>
    </View>
  )
}