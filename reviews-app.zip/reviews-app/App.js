import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
 
import Home from './Screens/Home'
import ReviewDetails from './Screens/ReviewDetails'
import About from './Screens/About'
 
const Drawerr = createDrawerNavigator();
 
export default function App() {
  return (
    <NavigationContainer>
      <Drawerr.Navigator useLegacyImplementation initialRouteName="Home">
        <Drawerr.Screen name="Home" component={Home} />
        <Drawerr.Screen name="ReviewDetails" component={ReviewDetails} />
        <Drawerr.Screen name="About" component={About} />
      </Drawerr.Navigator>
    </NavigationContainer>
  );
}
 
