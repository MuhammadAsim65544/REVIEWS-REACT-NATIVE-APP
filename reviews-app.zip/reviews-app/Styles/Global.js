import React from 'react';
import{ StyleSheet} from 'react-native';

export const golbalStyles=StyleSheet.create({
  container:{
    flex:1,
    padding:24,
    backgroundColor:'pink',
  },
  titleText:{
    color:'gray',
    fontWeight:'bold',
    fontSize:18,
    marginTop:10,
  },
  reviewdetail:{
    backgroundColor:'coral',
    color:'black',
    marginTop:5,
    borderColor:'black',
    borderWidth:1,
  }
})